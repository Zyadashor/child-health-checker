# child-health-checker
AI-based child symptom assessment web app (React + Flask)
